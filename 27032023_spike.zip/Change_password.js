import { useEffect } from "react";
import $ from "jquery";
import { useNavigate } from "react-router-dom";

function passChange(){  
  if($('#new_pass').val()!='' && $('#confirm_new_pass').val()!=''){
  if($('#new_pass').val()!=$('#confirm_new_pass').val()){
    $("#error_pop span").text('New and Confirm password do not match');
    $("#error_pop").fadeIn('slow');

    setTimeout(() => {
      $("#error_pop").fadeOut('slow');
    }, 2000);
  }else{

    var details={old_pass:$('#old_pass').val(),new_pass:$('#new_pass').val(),confirm_new_pass:$('#confirm_new_pass').val(),
  user_id:localStorage.getItem('userIds')}
      $.ajax({
      type:'post',
      url:'http://192.168.13.100:9999/change_pass',
      data:details,
      success:function(data){
        if(data.msg=='success'){
          $('#change_pass_reset').trigger('click');
          $("#success_pop span").text('Password Changed successfully');
          $("#success_pop").fadeIn('slow');
      
          setTimeout(() => {
            $("#success_pop").fadeOut('slow');
          }, 2000);
        }else{
          $("#error_pop span").text('Old Password is incorrect');
          $("#error_pop").fadeIn('slow');

          setTimeout(() => {
            $("#error_pop").fadeOut('slow');
          }, 2000);
        }
      }
    }) 
  }
  }

}


var navigate='';
function Change_password(){
  navigate=useNavigate();
  useEffect(()=>{    
    $('.mobile-bottom-nav').hide();
  })

  return(
    <div className="container change_pass">        
        <div className="pro-back-button" onClick={()=>navigate(-1)}><i className="fa-solid fa-angle-left"></i></div>
        <div className="security_image" style={{backgroundImage:"url('"+process.env.PUBLIC_URL+"change_pass.png')"}}></div>
        <div className="changepass_input_fields">
          <form>
          <input name="old_pass" id="old_pass" placeholder="Old Password" type="text" className="form-control"/>
          <input name="new_pass" id="new_pass" placeholder="New Password" type="text" className="form-control"/>
          <input name="confirm_new_pass" id="confirm_new_pass" placeholder="Confirm New Password" type="text" className="form-control"/>
          <input name="change_pass" id="change_pass" onClick={passChange} type="button" value="CHANGE" className="btn btn-primary"/>
          <input type="reset" id='change_pass_reset' style={{display:'none'}}/>
          </form>          
        </div>
    </div>
  )
}
export default Change_password;
// import $ from 'jquery';

// function UserDataLog(){

// $.ajax({
//     type:'post',
//     url:'http://192.168.13.100:9999/getUserDetails',
//     data:{'userId':localStorage.getItem('usersId')},
//     success:function(data){
//         // console.log(data.name);
//     }
// })

// }
// export default UserDataLog;
import './Settings.css';
import 'bootstrap/dist/css/bootstrap.css';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import Cookies from 'universal-cookie';
import $ from 'jquery';

var navigate='';
const cookies = new Cookies();
function logout(){
  localStorage.setItem('userIds','')
    navigate('/');
}

const Settings = () => {  

 navigate=useNavigate();

useEffect(()=>{
    $.ajax({
		type:'post',
		url:'http://192.168.13.100:9999/getUserDetails',
		data:{'userId':localStorage.getItem('userIds')},
		success:function(data){		  
	  $('#setting-page-name').html(data.data.name);
	  $('#setting-page-pic').css('background-image','url('+data.data.user_pic+')');
		}
	})
    $('.mobile-bottom-nav').show();
},[])

return (
//   <div>
//   <div className="settiings-main-back">
//   <div className="prof-container">
//      <div className="img-border" style={{border:'5px solid rgb(255 255 255)',borderRadius:'60px'}}>
//   <img src="test.jpg" width="100" height="100" style={{borderRadius:'60px'}} />
// </div>
//   <h4 className="settings-name">john Doe</h4>
//   </div>
//   </div>
// <div className="settings-tile-items">
// <div className="settings-tiles"><FontAwesomeIcon icon={faEdit} /><p className="settings-tile-name">Edit profile</p><i className="fa fa-angle-right"></i></div>
// <div className="settings-tiles"><FontAwesomeIcon icon={faGear} /><p className="settings-tile-name">Settings</p><i className="fa fa-angle-right"></i></div>
// <div className="settings-tiles"><FontAwesomeIcon icon={faLock} /><p className="settings-tile-name">Change Password</p><i className="fa fa-angle-right"></i></div>
// <div onClick={logout} className="settings-tiles"><FontAwesomeIcon icon={faSignOut} /><p className="settings-tile-name"  >Logout</p><i className="fa fa-angle-right"></i></div>
// </div>
// </div>

<div className="container-fluid body-div">
<div className='row settings-header'>
    <div className="col-6 user-name" id="setting-page-name">Test</div>
    <div className="col-6"><div id="setting-page-pic" style={{backgroundImage: "url('"+process.env.PUBLIC_URL+"default.png')"}} className="pro_pic"></div></div>
</div>
<div className="row tiles-row">
{/* <div className="col-6" style={{padding:"0px 0px 0px 10px"}}>
    <div className="setting-tiles"> profile <i style={{color:"#008aff"}} className="fa fa-user" aria-hidden="true"></i></div>
    <div className="setting-tiles"> password <i style={{color:"#3094c0"}} className="fa fa-key" aria-hidden="true"></i></div>
</div>
<div className="col-6" style={{padding:"0px 5px 0px 5px"}}>
<div className="setting-tiles">app settings <i style={{color:"green"}} className="fa-solid fa-globe"></i>
</div>            
<div className="setting-tiles">logout <i style={{color:"#ff9600"}} className="fas fa-sign-out-alt"></i></div> */}

<div className="setting-tiles" onClick={()=>navigate('/Update_profile')}>Profile<i style={{color:"#008aff",paddingLeft:"5px"}} className="fa fa-user" aria-hidden="true"></i></div>
<div className="setting-tiles" onClick={()=>navigate('/Change_password')}> Password <i style={{color:"#3094c0"}} className="fa fa-key" aria-hidden="true"></i></div>                    
<div className="setting-tiles">Settings <i style={{color:"green"}} className="fa-solid fa-globe"></i></div>
<div className="setting-tiles">Info <i style={{color:"#7e7e7e"}} className="fa fa-info-circle"></i></div>
<div className="setting-tiles" onClick={logout}>Logout <i style={{color:"#ff9600"}} className="fas fa-sign-out-alt"></i></div> 
</div>
</div>

)

}

export default Settings;
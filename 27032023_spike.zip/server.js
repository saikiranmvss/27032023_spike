var express = require('express');
var app = express();
var mysql= require('mysql');
const http = require('http');
var session = require('express-session');
const server = http.createServer(app)
const { Server } = require("socket.io");
var bodyParser=require('body-parser');
var cookieParser = require('cookie-parser');
var fs=require('fs');
var formidable=require('formidable');
var path=require('path');
var mv=require('mv');

app.use("../public", express.static(path.join(__dirname, 'public')));

// const io = new Server(server);
const io= new Server(server,{
  cors:{
    origin:"http://192.168.13.100:3000",
    method:['GET','POST'],
  },
});

const lib = require('./functions.js');
var dbQueryClass=new lib.UsersMain(); 
app.use(express.static(__dirname + '/public'));
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.set('view-engine','ejs');
app.use(session({secret: "Shh, its a secret!",saveUninitialized:true,resave:false}));
var os=require('os');
var network=os.networkInterfaces();
var networksIps=[];
for (const Ips of Object.keys(network)) {    
    networksIps.push(network[Ips][1]['address']);
}
const cors = require("cors");
const { resourceUsage } = require('process');
app.use(cors({
  origin: '*'
}));
app.all("/*", function(req, res, next){
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
  next();
});
app.post('/message',function(req,res){      
  res.json({msg:'success'});
})
app.post('/validate',async(req,res)=>{        
    var users =new lib.UsersMain(); 
    var userRes=await users.UserData(req.body.email,req.body.password);    
    res.json({msgs:userRes.id});
})
app.post('/allusersdata',async(req,res)=>{      
  var users =new lib.UsersMain();   
  var allUsers=[];
  var userHomeData= await users.userChatsIds(req.body.id);  
  for(var i =0 ; i < userHomeData.length;i++){    
    var dataFinal=await users.userOriMsg(req.body.id,userHomeData[i].ids);
    allUsers[i]= dataFinal[0];   
        
  }
    // var allUsers=await users.userDatamain(req.body.id);    
res.json({allUsers})
})

app.post('/usersdata',async(req,res)=>{  
  var users =new lib.UsersMain(); 
  var allUsesrsName=[];
var allUsesrsName=await users.userNamesPage(req.body.id);
res.json({allUsesrsName})
})

app.post('/logout_user',async(req,res)=>{
  var ids=req.session.user_ids;
  
})

app.post('/user_chat',async(req,res)=>{
  var chat_ress= new lib.UsersMain();  
  var chat_res= await chat_ress.singleUserChat(req.body.ownId,req.body.id);    
  if(chat_res[0]!=undefined){
    var chat_return1=chat_res[0];
  }else{
    var chat_return1=[];
  }

  if(chat_res[1]!=undefined){
    var chat_return2=chat_res[1];
  }else{
    var chat_return2=[];
  }  

  var dismsg='';
  var displayMsgArray=[];
  for(const mainmsgings of chat_return1){  
      if(mainmsgings.sender_id==req.body.ownId){            
          dismsg+='<div class="msg_rec_div">'+mainmsgings.msg_content+'</div>';
      }else{ 
              dismsg+='<div class="msg_sent_div">'+mainmsgings.msg_content+'</div>';;            
                  
      }
    }
    displayMsgArray[0]=dismsg;
  res.json({chat_return1,chat_return2,displayMsgArray});
})

app.post('/change_pass',async(req,res)=>{
  var CheckPass=new lib.UsersMain();
  var Resultannt=await CheckPass.ChangePass(req.body.user_id,req.body.old_pass,req.body.new_pass);
  res.json({msg:Resultannt});
})
var friendsData=[];
var newFrnds=[];
var newfriendsData=[];
app.post('/friendsFetch',async(req,res)=>{
  friendsData.length=0;
  var fetchFrnds= new lib.UsersMain();
  var fetchFriends= await fetchFrnds.FriendsList(req.body.friendsFetchId);
  for(var i=0;i<fetchFriends.length;i++){
    var secQry=await fetchFrnds.FriendsData(fetchFriends[i]);
    friendsData.push(secQry);
  }  
  res.json({frnds:friendsData})
})

app.post('/Addfriends',async(req,res)=>{
  newFrnds.length=0;
  var newFrndClass=new lib.UsersMain(); 
  newFrnds = await newFrndClass.FriendsList(req.body.ownId);
  newFrnds.push(req.body.ownId);   
    var secNewFrndQry=await newFrndClass.NewFriendsData();
    for(var i=0;i<newFrnds.length;i++){      
      secNewFrndQry.splice(newFrnds[i]-1,1,0);
    }    
    var newUsers = secNewFrndQry.filter(function (letter) {
      return letter !== 0;
  });
    res.json({newFrnds:newUsers});
})

app.post('/upload_image',async(req,result)=>{
  var uploadImage=new lib.UsersMain();   
  let form= new formidable.IncomingForm();
  form.parse(req,async(error,fields,file)=>{
    if(fields.uploaded=='yes'){


    let Oldfilepath=file.image.filepath;
    let newFilepath='../public/';
    var ext=file.image.originalFilename.split('.')[1];
    var name=Date.now()+'_propic.'+ext;
    let fileName=name;

   var Uploaded=await uploadImage.uploadImages(fileName,fields.userId);

    mv(Oldfilepath,newFilepath+fileName,function(err,res){
      if(err){
        console.log(err);
      }else{

        result.json({setImage:fileName});
      }
    })
  }else{
    fileName='default.png';    
   var Uploadeddefault=await uploadImage.uploadImages(fileName,fields.userId);    
    result.json({setImage:'default.png'})
  }
    
  })
})

app.post('/getUserDetails',async(req,res)=>{
  var userLog=new lib.UsersMain();   
  userLogsData=await userLog.FriendsData(req.body.userId);  
  res.json({data:JSON.parse(JSON.stringify(userLogsData))})
})

app.post('/addFrnd',async(req,res)=>{
  var colName='sent_requests';
var getsentReq=await dbQueryClass.getFrndCol(req.body.ownUserId,colName);
res.json({getsentReq:getsentReq});
})

app.post('/getReceivedRequestsLoad',async(req,res)=>{
  var colName="received_requests";
  var getRecReq=await dbQueryClass.getFrndCol(req.body.ownUserId,colName);
  console.log(getRecReq);
  res.json({getRecReq:getRecReq});
})

app.post('/getSentRequestsLoad',async(req,res)=>{
  var colName="sent_requests";
  var getSentReqload=await dbQueryClass.getFrndCol(req.body.ownUserId,colName);
  console.log(getSentReqload);
  res.json({getSentReqload:getSentReqload});
})

var usersSessions=[];
io.on('connection', (socket) => {  
  socket.on('loggedin',function(data){    
    usersSessions[data]=socket.id;            
  })

  socket.emit('connection','connected');
  socket.on('send_message',async(data)=>{
    var callInsert= new lib.UsersMain();
    var insertId=await callInsert.inserting(data[2],data[1],data[0]);
    var msgDataSent=[data[0],data[1],data[2],insertId];
    socket.to(usersSessions[data[1]]).emit('received_msg',msgDataSent);
  })

  socket.on('update_msg',async(data)=>{
    var callUpdate=new lib.UsersMain();  
    queryUpdate= await callUpdate.UpdateMsg(data);
  })

})

const PORT = process.env.PORT || 9999;
server.listen(9999,()=>{
  console.log(`server runs`);
})
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from 'axios';
import $ from 'jquery';
import 'react-loading-skeleton/dist/skeleton.css'

var navigate='';
function Addfriends(){ 
  const [newFends,NewuserState]=useState([]);  

function sentRequests(){
  $.ajax({
    type:'post',
    url:'http://192.168.13.100:9999/getSentRequests',
    data:{userId:localStorage.getItem('userIds')},
    success:function(data){
      $('#page-name').html('RECEIVED REQUESTS');
    }
  })
}


function receivedRequests(){
  $.ajax({
    type:'post',
    url:'http://192.168.13.100:9999/getReceivedRequests',
    data:{userId:localStorage.getItem('userIds')},
    success:function(data){
      $('#page-name').html('SENT REQUESTS');
    }
  })
}

function loadSendReq(){
  $.ajax({
    type:'post',
    url:'http://192.168.13.100:9999/getSentRequestsLoad',
    data:{userId:localStorage.getItem('userIds')},
    success:function(data){
      // $('#page-name').html('SENT REQUESTS');
      // console.log(data);
    }
  })
}


function loadReceivedReq(){
  $.ajax({
    type:'post',
    url:'http://192.168.13.100:9999/getReceivedRequestsLoad',
    data:{userId:localStorage.getItem('userIds')},
    success:function(data){
      // console.log(data);
      // $('#page-name').html('SENT REQUESTS');
    }
  })
}
function addFrnd(e){
  var addUserId=e.target.getAttribute('data-id');
  $.ajax({
    type:'post',
    url:'http://192.168.13.100:9999/addFrnd',
    data:{addUserId:addUserId,ownUserId:localStorage.getItem("userIds")},
    success:function(data){
      // console.log(data.getsentReq.sent_requests);
    }
  })
}


  useEffect(()=>{      
    loadReceivedReq();
  loadSendReq();
  axios
  .post('http://192.168.13.100:9999/Addfriends',{ownId:localStorage.getItem('userIds')})
  .then((response)=>{    
    NewuserState(response.data.newFrnds);
  })
},[])

return(
  <div className="friends_main_div container">
    <div className="friend_requests">
    <div className="page-name" id="page-name">ADD FRIENDS</div>
    <div style={{paddingRight:" 20px"}} id="sent_requests" onClick={sentRequests}><i className="fa-solid fa-user-check"></i> <span className="request_count">6</span></div>       
    <div id="received_requests" onClick={receivedRequests}><i className="fa-solid fa-user-plus"></i><span className="sent_request_count">6</span></div>
    </div>
    {newFends.map(function(item,index){
  return <div key={item.user_id} className="friend_card row">    
    <div className="friend_image col-6" style={{backgroundImage:'url('+process.env.PUBLIC_URL+item.user_pic}}></div>
    <div className="friend_name_panel col-6">
      <h6>{item.name}</h6>
      <div className="friend_buttons">
       <input type="button" className="btn add_friend_btn" value="Add friend" data-id={item.user_id} id="add_friend" onClick={e=>addFrnd(e)}/> 
       <input type="button" className="btn msg_friend_btn" value="Message" id="msg_friend" /> 
      </div>
    </div>
  </div>
})} 
  </div>
)
      }


export default Addfriends;
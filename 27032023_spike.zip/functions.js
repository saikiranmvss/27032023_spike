const { CookieSharp } = require('@mui/icons-material');
var mysql=require('mysql');
var db=mysql.createConnection({ host:'localhost',user:'root',password:'',database:'chatapp'});
var ResUsersData=[];    

class UsersMain{
    UserData(email_entered,pass_entered){
        var usersQuery="select getUsers_go(?,?) as id";
        return new Promise((resolve,reject)=>{
            db.query(usersQuery,[email_entered,pass_entered],function(err,res){            
                return resolve(res[0]);                
            })
            })
    }

    
    userChatsIds(id){        
        var sql='select * from (select sender_id as ids,msg_createddate from users_messages where receiver_id = ? GROUP by sender_id UNION SELECT receiver_id as ids,msg_createddate as ids FROM users_messages where sender_id = ? GROUP by receiver_id ) as usersData GROUP by ids ORDER by msg_createddate desc';
        return new Promise ((resolve,reject) =>{
            db.query(sql,[id,id],function(err,res){                
                if(err){
                    var data="error";                               
                }else{            
                    data=res;                                                
                }   
                resolve(data);             
            })
        })
    }

    userOriMsg(userId,otherUserId){
        var sql2='call getUsersData(?,?)';      
        return new Promise ((resolve,reject) =>{                         
            db.query(sql2,[userId,otherUserId],function(err,res){                
                if(err){
                }else{                    
                    resolve(res[0]);
                }              
            })   
        })     
    }

    userDatamain(id){
        var homeMsgs=[]; 
        var Usersdata="select users_messages.receiver_id,users_messages.msg_content,users.user_pic,users.name,users.user_id from users INNER JOIN users_messages ON users.user_id=users_messages.receiver_id or users.user_id=users_messages.sender_id where users.user_id=? and users_messages.receiver_id!=1 GROUP by receiver_id Order by msg_createddate DESC";
        return new Promise((resolve,reject)=>{
            db.query(Usersdata,[id],function(err,res){                                     
                return resolve(res);
            })
        })
    }

    userNamesPage(id){        
        var Userscalldata="select * from users where user_id!=?";
        return new Promise((resolve,reject)=>{
            db.query(Userscalldata,[id],function(err,res){                   
                return resolve(res);
            })
        })
    }

    singleUserChat(ownId,id){
        var Chat_array=[];        
        var messagesRes='call getSingleUserChat(?,?)';
        return new Promise((resolve,reject)=>{
            db.query(messagesRes,[ownId,id],function(err,res){                                
                if(res[0]!=''){
                    Chat_array[0]=res[0];
                }
                if(res[1]!=''){
                    Chat_array[1]=res[1];
                }
                return resolve(Chat_array);
            })
        })
    }

    inserting(main,other,mesg){     

            var sql="insert into users_messages(msg_content,msg_status,receiver_id,receiver_status,sender_id,sender_status,user_id)values(?,1,?,0,?,1,?)";        
        
        return new Promise((resolve,reject)=> {
            db.query(sql,[mesg,other,main,main],function(err,res){     
                if(err){
                    console.log(err);
                }
                return resolve(res.insertId);            
            })
        })
    }

    UpdateMsg(data){
        var updateQry='update users_messages set receiver_status = ? where msg_id= ?';
        console.log(data[2]);
        return new Promise((resolve,reject)=>{
            db.query(updateQry,[data[3],data[2]],function(err,res){
                if(err){
                    console.log('update query error');
                }else{
                    console.log('update query success');
                }
            })
        })
    }

    ChangePass(userIds,oldPass,newPass){
        var passCheck="select * from users where user_id=? and password=?";
        return new Promise((resolve,reject)=>{
            db.query(passCheck,[userIds,oldPass],function(err,res){                
                if(res  && res.length > 0){
                    db.query("Update users set password=? where user_id=?",[newPass,userIds],function(err,res){                             
                    })
                    var msg='success';
                }else{
                    var msg='invalid';
                }
                return resolve(msg);
            })
        })
    }

       FriendsList(userId){
        var friendsQry="select friends from users where user_id=?";                 
        return new Promise((resolve,reject)=>{            
            db.query(friendsQry,[userId],async(err,res)=>{
                if(err){
                    console.log('Error Fetching friends')
                }else{                
                    resolve(JSON.parse(res[0].friends));                                            
                            
                }
            })
        })
    }

        FriendsData(UserId){
            var userData='select name,email,user_id,user_pic from users where user_id=?';
            return new Promise((resolve,reject)=>{             
            db.query(userData,[UserId],async(err,result)=>{                            
                resolve(result[0]);                
            })               
        })  
        }

        NewFriendsData(){
            var userData='select name,email,user_id,user_pic from users';
            return new Promise((resolve,reject)=>{             
            db.query(userData,async(err,result)=>{ 
                // console.log(result);                           
                resolve(JSON.parse(JSON.stringify(result)));
            })               
        })  
        }

        uploadImages(filename,userId){
            var UpdateImage='update users set user_pic=? where user_id=?';
            return new Promise((resolve,reject)=>{
                db.query(UpdateImage,[filename,userId],function(err,res){
                    if(err){
                        resolve('1');
                    }else{
                        resolve('0');
                    }
                })
            })
        }

        addFrnd(addUserId,userId){
            return new Promise((resolve,reject)=>{
                db.query(UpdateImage,[filename,userId],function(err,res){
                    if(err){
                        resolve('1');
                    }else{
                        resolve('0');
                    }
                })
            })
        }

        getFrndCol(userId,colName){
            if(colName=='sent_requests'){
                var sql='select sent_requests from users where user_id=?';
            }else if(colName=='received_requests'){
                var sql='select received_requests from users where user_id=?';
            }
            return new Promise((resolve,reject)=>{
                db.query(sql,[userId],function(err,res){
                    if(err){
                        console.log(err);
                    }else{      
                        console.log(res[0]);                  
                        resolve(res[0]);
                    }
                })
            })
        }
}

module.exports={ UsersMain };
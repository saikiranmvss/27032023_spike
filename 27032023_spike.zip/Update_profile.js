import { useEffect } from "react";
import $ from "jquery";
import { useNavigate } from "react-router-dom";
import axios from 'axios';

var navigate='';
function Update_profile(){
  navigate=useNavigate();
  $(document).on('click','#pro_pic',function(){           
    $('.change_pic_popup').slideDown();
  })
  $(document).on('click','#cancel_pop',function(){      
    $('.change_pic_popup').slideUp();
  })
  function triggerClick(){      
    $('#upload_image').trigger('click');
    $('.change_pic_popup').slideUp();
  }
  // function callUpload(e){
  //   console.log(e);
  // }
  function uploadImage(element){
    var Image=element.target.files[0];
    var formdata= new FormData();
    formdata.append('image',Image);
    formdata.append('userId',localStorage.getItem('userIds'));
    formdata.append('uploaded','yes');    
    $.ajax({
      type:'post',
      url:'http://192.168.13.100:9999/upload_image',
      contentType:false,
      cache: false,
      processData:false,
      data:formdata,
      success:function(datas){
        $('#upload_image').val('');                
        $('#pro_pic').css('background-image',"url("+datas.setImage+")");
        $('.change_pic_popup').slideUp();
      }
    })
  }

  function deleteImage(){
    var formdata= new FormData();
    formdata.append('userId',localStorage.getItem('userIds'));
    formdata.append('uploaded','no');
    $.ajax({
      type:'post',
      url:'http://192.168.13.100:9999/upload_image',
      contentType:false,
      cache: false,
      processData:false,
      data:formdata,
      success:function(datas){
        $('#upload_image').val('');                
        $('#pro_pic').css('background-image',"url("+datas.setImage+")");
        $('.change_pic_popup').slideUp();
      }
    })
  }
  useEffect(()=>{    
    $.ajax({
      type:'post',
      url:'http://192.168.13.100:9999/getUserDetails',
      data:{'userId':localStorage.getItem('userIds')},
      success:function(data){        
      $('#setting-page-name').html(data.data.name);
      $('#setting-page-pic').css('background-image','url('+data.data.user_pic+')');
      $('#pro_pic').css('background-image',"url("+data.data.user_pic+")");
      }
    })
    $('.mobile-bottom-nav').hide();

  },[])

  return(
    <div className="update_pro_div">
  <div className="pro-back-button" onClick={()=>navigate(-1)}>
  <i className="fa-solid fa-angle-left"></i>
  </div>
<div className="center-div">
  <div className="update-pro_pic" id="pro_pic" style={{backgroundImage:"url('"+process.env.PUBLIC_URL+"PHOTOGRAPH1.jpg')"}}>
  <div className="edit-text-div" id="edit-div"><span className="edit_propic">Edit</span></div>
  </div>
  </div>
  <div className="update-details">
 <div className="input-card">
  <img src="id-card.png" alt="" className="input-favs" />
  
   <input disabled type="text" value="Sai kiran" className="form-control update-form-control" id="name" name="name" /></div>
 <div className="input-card">
  <img src="email.png" alt="" className="input-favs" />
  
  <input disabled type="email" value="saisatya51@gmail.com" className="form-control update-form-control" id="email" name="email" /></div>
 <div className="input-card">
  <img src="telephone.png" alt="" className="input-favs" />
  <input type="file" accept="image/*" id="upload_image" name="upload_image" capture="user" style={{display:'none'}} onChange={e=>uploadImage(e)} />
  <input disabled type="tel" value="6668885962" className="form-control update-form-control" id="phone" name="phone" /></div>
  </div>
  <div className="change_pic_popup">
    <h5 id="delete_pic" className="delete_pic" onClick={deleteImage}>Delete Photo</h5>
    <h5 id="choose_pic" onClick={triggerClick} className="choose_pic">Choose Photo</h5>
    <h5 id="cancel_pop" className="cancel_pop">Cancel</h5>
  </div>
</div>
  )
}
export default Update_profile;
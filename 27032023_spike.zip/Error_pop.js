
function Error_pop(){
    return (
        <div>
        <div className="error_pop" id="error_pop"><i className="fa fa-exclamation-triangle" style={{paddingRight:"10px"}} aria-hidden="true"></i><span>Invalid Password</span></div>
        <div className="success_pop" id="success_pop"><i className="fa fa-check" style={{paddingRight:"10px"}} aria-hidden="true"></i><span>Password Changed successfully</span></div>     
        </div>
    )
}

export default Error_pop;
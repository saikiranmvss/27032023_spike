import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import 'react-loading-skeleton/dist/skeleton.css';
import $ from 'jquery';

var navigate='';
function CheckSession(){ 
  navigate=useNavigate();

  useEffect(()=>{  
  if(localStorage.getItem('userIds')!=''){
    navigate('/Allusers');    
  }else{
    navigate('/');
  }
},[])           
      }


export default CheckSession;